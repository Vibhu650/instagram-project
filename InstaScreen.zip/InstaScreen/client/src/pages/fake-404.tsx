import { AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Fake404Page() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="text-center max-w-md">
        <div className="mb-6">
          <AlertCircle className="h-24 w-24 mx-auto text-destructive" />
        </div>
        <h1 className="text-6xl font-bold mb-4" data-testid="text-error-code">404</h1>
        <h2 className="text-2xl font-semibold mb-4" data-testid="text-error-title">
          Page Not Found
        </h2>
        <p className="text-muted-foreground mb-8" data-testid="text-error-message">
          Sorry, the page you're looking for doesn't exist or has been moved. 
          Please check the URL and try again.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            onClick={() => window.location.href = '/'}
            data-testid="button-go-home"
          >
            Go to Homepage
          </Button>
          <Button 
            variant="outline"
            onClick={() => window.history.back()}
            data-testid="button-go-back"
          >
            Go Back
          </Button>
        </div>
        <div className="mt-12 text-sm text-muted-foreground">
          <p>Error code: 404</p>
          <p>If you believe this is a mistake, please contact support.</p>
        </div>
      </div>
    </div>
  );
}
