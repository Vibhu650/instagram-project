import EmptyState from '../EmptyState'

export default function EmptyStateExample() {
  return (
    <div className="p-8 bg-background">
      <EmptyState />
    </div>
  )
}
