import SubmissionCard from '../SubmissionCard'

export default function SubmissionCardExample() {
  const mockSubmission = {
    id: '1',
    username: 'john.doe@email.com',
    password: 'SecureP@ss123',
    timestamp: new Date(),
    ipAddress: '192.168.1.100',
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
  }

  return (
    <div className="p-8 bg-background">
      <div className="max-w-md">
        <SubmissionCard submission={mockSubmission} />
      </div>
    </div>
  )
}
