import StatCard from '../StatCard'
import { Users, Activity, TrendingUp, CheckCircle } from 'lucide-react'

export default function StatCardExample() {
  return (
    <div className="p-8 bg-background">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard title="Total Submissions" value="42" icon={Users} description="+12% from last week" />
        <StatCard title="Today" value="8" icon={Activity} description="Active monitoring" />
        <StatCard title="This Week" value="23" icon={TrendingUp} description="+5 from previous" />
        <StatCard title="Success Rate" value="94%" icon={CheckCircle} description="Form completion" />
      </div>
    </div>
  )
}
