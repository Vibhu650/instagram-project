import EducationalBanner from '../EducationalBanner'

export default function EducationalBannerExample() {
  return <EducationalBanner />
}
