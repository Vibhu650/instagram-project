import InstagramLoginForm from '../InstagramLoginForm'

export default function InstagramLoginFormExample() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <InstagramLoginForm onSubmit={(username, password) => console.log('Submitted:', { username, password })} />
    </div>
  )
}
