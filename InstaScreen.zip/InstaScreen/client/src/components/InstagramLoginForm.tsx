import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";

interface InstagramLoginFormProps {
  onSubmit?: (username: string, password: string) => void;
}

export default function InstagramLoginForm({ onSubmit }: InstagramLoginFormProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onSubmit) {
      onSubmit(username, password);
    }
  };

  const isFormValid = username.length > 0 && password.length > 0;

  return (
    <div className="w-full max-w-sm mx-auto">
      <div className="border border-border bg-background p-10 rounded-sm" data-testid="card-login">
        <div className="flex flex-col items-center mb-8">
          <h1 className="text-5xl font-serif italic" style={{ fontFamily: "'Architects Daughter', cursive" }}>
            Instagram
          </h1>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <div className="relative">
            <Label htmlFor="username" className="sr-only">
              Phone number, username, or email
            </Label>
            <Input
              id="username"
              type="text"
              placeholder="Phone number, username, or email"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="h-10 text-sm bg-muted/30 border-input"
              data-testid="input-username"
            />
          </div>

          <div className="relative">
            <Label htmlFor="password" className="sr-only">
              Password
            </Label>
            <Input
              id="password"
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-10 text-sm bg-muted/30 border-input"
              data-testid="input-password"
            />
          </div>

          <Button
            type="submit"
            disabled={!isFormValid}
            className="w-full h-10 rounded-sm font-semibold text-sm"
            data-testid="button-login"
          >
            Log in
          </Button>
        </form>

        <div className="flex items-center gap-4 my-6">
          <Separator className="flex-1" />
          <span className="text-sm font-semibold text-muted-foreground">OR</span>
          <Separator className="flex-1" />
        </div>

        <Button
          variant="ghost"
          className="w-full h-10 text-sm font-semibold text-primary hover:text-primary"
          data-testid="button-facebook-login"
        >
          <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24">
            <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
          </svg>
          Log in with Facebook
        </Button>

        <div className="text-center mt-4">
          <a href="#" className="text-xs text-primary hover:text-primary/80" data-testid="link-forgot-password">
            Forgot password?
          </a>
        </div>
      </div>

      <div className="border border-border bg-background p-6 rounded-sm mt-4 text-center" data-testid="card-signup">
        <p className="text-sm">
          Don't have an account?{" "}
          <a href="#" className="text-primary font-semibold hover:text-primary/80" data-testid="link-signup">
            Sign up
          </a>
        </p>
      </div>

      <div className="text-center mt-6">
        <p className="text-sm mb-4">Get the app.</p>
        <div className="flex justify-center gap-2">
          <img
            src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='135' height='40' fill='none'%3E%3Crect width='135' height='40' rx='5' fill='%23000'/%3E%3Ctext x='50%25' y='50%25' fill='%23fff' font-size='10' text-anchor='middle' dominant-baseline='middle'%3EApp Store%3C/text%3E%3C/svg%3E"
            alt="Download on App Store"
            className="h-10"
            data-testid="img-app-store"
          />
          <img
            src="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='135' height='40' fill='none'%3E%3Crect width='135' height='40' rx='5' fill='%23000'/%3E%3Ctext x='50%25' y='50%25' fill='%23fff' font-size='10' text-anchor='middle' dominant-baseline='middle'%3EGoogle Play%3C/text%3E%3C/svg%3E"
            alt="Get it on Google Play"
            className="h-10"
            data-testid="img-google-play"
          />
        </div>
      </div>
    </div>
  );
}
