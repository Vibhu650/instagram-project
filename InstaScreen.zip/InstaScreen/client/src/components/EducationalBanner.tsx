import { AlertTriangle, X } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";

export default function EducationalBanner() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    <div className="sticky top-0 z-50 bg-destructive text-destructive-foreground px-6 py-4 flex items-center justify-between gap-4" data-testid="banner-educational">
      <div className="flex items-center gap-3">
        <AlertTriangle className="h-5 w-5 flex-shrink-0" />
        <p className="text-sm font-semibold">
          EDUCATIONAL DEMO - This is a security awareness simulation
        </p>
      </div>
      <Button
        variant="ghost"
        size="icon"
        onClick={() => setIsVisible(false)}
        className="h-8 w-8 flex-shrink-0 text-destructive-foreground hover:bg-destructive-foreground/10"
        data-testid="button-dismiss-banner"
      >
        <X className="h-4 w-4" />
      </Button>
    </div>
  );
}
