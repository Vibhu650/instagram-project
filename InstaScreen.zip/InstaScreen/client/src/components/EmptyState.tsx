import { Database } from "lucide-react";

export default function EmptyState() {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center" data-testid="container-empty-state">
      <div className="w-24 h-24 rounded-full bg-muted flex items-center justify-center mb-4">
        <Database className="h-12 w-12 text-muted-foreground" />
      </div>
      <h3 className="text-lg font-semibold mb-2" data-testid="text-empty-title">
        No submissions yet
      </h3>
      <p className="text-sm text-muted-foreground max-w-md" data-testid="text-empty-description">
        Share the demo login page to start capturing form data for educational purposes. All submissions will appear here in real-time.
      </p>
    </div>
  );
}
